export interface game {
    id: string;
    result: Array<number>;
}