import { YearDate } from "./types";
import { Month } from "./Month";

export class Year {
    date: YearDate;
    monthes: Array<Month>;

    constructor(date: YearDate) {
        this.date = { year: date.year };
        this.monthes = [];
    }

    getExistMonthes() {
        return this.monthes.map((month) => month.date.month);
    }

    hasMonth(month: number) {
        return this.getExistMonthes().indexOf(month) !== -1;
    }
}
