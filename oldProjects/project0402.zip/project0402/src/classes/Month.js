"use strict";
exports.__esModule = true;
var Month = /** @class */ (function () {
    function Month(date) {
        this.date = { year: date.year, month: date.month };
        this.days = [];
    }
    Month.prototype.getExistDays = function () {
        return this.days.map(function (day) { return day.date.date; });
    };
    Month.prototype.hasDay = function (date) {
        return this.getExistDays().indexOf(date) !== -1;
    };
    return Month;
}());
exports.Month = Month;
