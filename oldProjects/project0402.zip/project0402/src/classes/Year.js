"use strict";
exports.__esModule = true;
var Year = /** @class */ (function () {
    function Year(date) {
        this.date = { year: date.year };
        this.monthes = [];
    }
    Year.prototype.getExistMonthes = function () {
        return this.monthes.map(function (month) { return month.date.month; });
    };
    Year.prototype.hasMonth = function (month) {
        return this.getExistMonthes().indexOf(month) !== -1;
    };
    return Year;
}());
exports.Year = Year;
