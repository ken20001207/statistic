"use strict";
exports.__esModule = true;
var Game = /** @class */ (function () {
    function Game(date, period, result) {
        this.date = date;
        this.period = period;
        this.result = result;
    }
    return Game;
}());
exports.Game = Game;
