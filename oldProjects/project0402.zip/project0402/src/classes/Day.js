"use strict";
exports.__esModule = true;
var Day = /** @class */ (function () {
    function Day(date) {
        this.date = date;
        this.games = [];
    }
    Day.prototype.getExistGames = function () {
        return this.games.map(function (game) { return game.period; });
    };
    Day.prototype.hasGame = function (gameid) {
        return this.getExistGames().includes(gameid);
    };
    return Day;
}());
exports.Day = Day;
