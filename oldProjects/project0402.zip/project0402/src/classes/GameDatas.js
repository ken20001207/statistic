"use strict";
exports.__esModule = true;
var GameDatas = /** @class */ (function () {
    function GameDatas() {
        this.years = [];
    }
    GameDatas.prototype.getExistYears = function () {
        return this.years.map(function (year) { return year.date.year; });
    };
    GameDatas.prototype.hasYear = function (year) {
        return this.getExistYears().includes(year);
    };
    return GameDatas;
}());
exports["default"] = GameDatas;
