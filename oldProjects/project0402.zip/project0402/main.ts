import * as electron from "electron";
import * as https from "https";
import { ipcMain } from "electron";

/** Classes */
class Year {
    date: YearDate;
    monthes: Array<Month>;

    constructor(date: YearDate) {
        this.date = { year: date.year };
        this.monthes = [];
    }

    getExistMonthes() {
        return this.monthes.map((month) => month.date.month);
    }

    hasMonth(month: number) {
        return this.getExistMonthes().indexOf(month) !== -1;
    }
}

class Month {
    date: MonthDate;
    days: Array<Day>;

    constructor(date: MonthDate) {
        this.date = { year: date.year, month: date.month };
        this.days = [];
    }

    getExistDays() {
        return this.days.map((day) => day.date.date);
    }

    hasDay(date: number) {
        return this.getExistDays().indexOf(date) !== -1;
    }
}

class GameDatas {
    years: Array<Year>;
    constructor() {
        this.years = [];
    }

    getExistYears() {
        return this.years.map((year) => year.date.year);
    }

    hasYear(year: number) {
        return this.getExistYears().includes(year);
    }
}

class Game {
    date: DayDate;
    period: number;
    result: Array<number>;

    constructor(date: DayDate, period: number, result: Array<number>) {
        this.date = date;
        this.period = period;
        this.result = result;
    }
}

class Day {
    date: DayDate;
    games: Array<Game>;

    constructor(date: DayDate) {
        this.date = date;
        this.games = [];
    }

    getExistGames() {
        return this.games.map((game) => game.period);
    }

    hasGame(gameid: number) {
        return this.getExistGames().includes(gameid);
    }
}

/** Types */

interface DayDate {
    year: number;
    month: number;
    date: number;
}

interface MonthDate {
    year: number;
    month: number;
}

interface YearDate {
    year: number;
}

/** Functions */

function sameDay(d1, d2) {
    return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
}

function getCarHistoryByPeriod(from: DayDate, to: DayDate, oriGameDatas: GameDatas = new GameDatas()) {
    return new Promise<GameDatas>(async (resolve, reject) => {
        try {
            var datep = new Date();
            var dateend = new Date();
            datep.setFullYear(from.year, from.month - 1, from.date);
            dateend.setFullYear(to.year, to.month - 1, to.date);
            dateend.setDate(dateend.getDate() + 1);
            var promises = new Array();
            while (!sameDay(datep, dateend)) {
                promises.push(
                    getCarHistoryByDay(datep.getFullYear(), datep.getMonth() + 1, datep.getDate()).then((day) =>
                        putDayIntoGameDatas(oriGameDatas, day)
                    )
                );
                datep.setDate(datep.getDate() + 1);
            }
            Promise.all(promises).then(() => resolve(oriGameDatas));
        } catch (err) {
            console.error(err);
            reject(err);
        }
    });
}

function putDayIntoGameDatas(gamedatas: GameDatas, day: Day) {
    if (!gamedatas.hasYear(day.date.year)) {
        gamedatas.years.push(new Year(day.date));
    }
    var thisYear = gamedatas.years.find((year) => year.date.year === day.date.year);
    if (!thisYear.hasMonth(day.date.month)) {
        thisYear.monthes.push(new Month(day.date));
    }
    var thisMonth = thisYear.monthes.find((month) => month.date.month === day.date.month);
    if (!thisMonth.hasDay(day.date.date)) {
        thisMonth.days.push(day);
    }
}

function getCarHistoryByDay(year: number, month: number, date: number) {
    return new Promise<Day>(async (resolve, reject) => {
        try {
            https.get(
                "https://988kjw.com/inc/get.asp?lt=vrpk10a&tt=lotteryList&dt=" + year + "-" + month + "-" + date,
                {
                    headers: {
                        "User-Agent":
                            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36",
                        Cookie: "ccsalt=e4d35ff5b245aecebd5fd355d6c9deb3; HJMK=3703790g984d1bc1c4d8a63f497dfc5455f9b461g1396me;",
                    },
                },
                function (response) {
                    if (response.statusCode > 300 && response.statusCode < 400 && response.headers.location) {
                        console.error("** 從 988kjw.com 抓取數據時發生了意外錯誤，以下是 response headers **");
                        console.error(response.headers);
                        reject();
                    } else {
                        var body = "";

                        response.on("data", function (chunk) {
                            body += chunk.toString();
                        });

                        response.on("end", async function () {
                            resolve(
                                await parseDayObject(JSON.parse(body), {
                                    year: year,
                                    month: month,
                                    date: date,
                                })
                            );
                            mainWindow.webContents.send("one-day-downloaded");
                        });
                    }
                }
            );
        } catch (err) {
            console.error(err);
        }
    });
}

function parseDayObject(data: Array<originGameData>, date: DayDate) {
    return new Promise<Day>((resolve, reject) => {
        try {
            var day = new Day(date);
            data.map((origame) => {
                day.games.push(new Game(date, origame.issue, origame.openNum));
            });
            day.games.sort((gameA, gameB) => gameA.period - gameB.period);
            resolve(day);
        } catch (err) {
            reject(err);
        }
    });
}

interface originGameData {
    openDateTime: string;
    issue: number;
    openNum: Array<number>;
    sumArr: Array<number>;
    dtArr: Array<number>;
    mimcryArr: any;
    formArr: any;
    sumStrArr: any;
}

/** Main */

const app = electron.app;
const BrowserWindow = electron.BrowserWindow;

app.allowRendererProcessReuse = true;

export var mainWindow: electron.BrowserWindow;

async function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
        },
    });
    mainWindow.loadFile("build/index.html");
    mainWindow.setMenu(null);
}

ipcMain.on("give-me-game-datas", async (event, data: any) => {
    var gamedata = await getCarHistoryByPeriod(data.from, data.to, store);
    event.reply("give-you-game-datas", gamedata);
});

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        app.quit();
    }
});

app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

/** 關於自動獲取歷史數據 */

var store = new GameDatas();

function downloadHistory(year: number) {
    return new Promise<string>((resolve, reject) => {
        https.get(
            "https://www.1396r.com/xyft/downloadhistory?t=csv&start=" + year + "-01-01&end=" + year + "-12-31",
            {
                headers: {
                    "User-Agent":
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36",
                    Cookie: "ccsalt=e4d35ff5b245aecebd5fd355d6c9deb3; HJMK=3703790g984d1bc1c4d8a63f497dfc5455f9b461g1396me;",
                },
            },
            function (response) {
                if (response.statusCode > 300 && response.statusCode < 400 && response.headers.location) {
                    console.error("** 從 www.1396r.com 抓取數據時發生了意外錯誤，以下是 response headers **");
                    console.error(response.headers);
                    reject();
                } else {
                    var body = "";

                    response.on("data", function (chunk) {
                        body += chunk.toString();
                    });

                    response.on("end", function () {
                        console.log("獲取 " + year + " 年的比賽數據完成");
                        resolve(body);
                    });
                }
            }
        );
    });
}

async function getHistory(year: number) {
    var dataString = await downloadHistory(year);
    var lines = dataString.split("\n");
    console.log("開始解析 " + year + " 年的比賽數據，共 " + lines.length + " 筆");
    lines.map((line) => {
        if (line.split(",")[1] === undefined) return;
        // 處理日期
        var dateArray = line.split(",")[0].split("-");
        var date = { year: +dateArray[0], month: +dateArray[1], date: +dateArray[2] };

        // 處理期數
        const period = +line.split(",")[1];

        // 處理結果
        var result = new Array<number>();
        for (var i = 2; i <= 11; i++) result.push(+line.split(",")[i]);

        // 創建場次物件
        var game = new Game(date, period, result);

        if (!store.hasYear(game.date.year)) {
            store.years.push(new Year(game.date));
        }
        var thisYear = store.years.find((year) => year.date.year === date.year);
        if (!thisYear.hasMonth(game.date.month)) {
            thisYear.monthes.push(new Month(game.date));
        }
        var thisMonth = thisYear.monthes.find((month) => month.date.month === date.month);
        if (!thisMonth.hasDay(game.date.date)) {
            thisMonth.days.push(new Day(game.date));
        }
        var thisDay = thisMonth.days.find((day) => day.date.date === date.date);
        thisDay.games.push(game);
    });
    console.log(" => " + year + " 年的比賽數據已經解析完成並可用於統計分析");
}
