"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var electron = require("electron");
var https = require("https");
var electron_1 = require("electron");
/** Classes */
var Year = /** @class */ (function () {
    function Year(date) {
        this.date = { year: date.year };
        this.monthes = [];
    }
    Year.prototype.getExistMonthes = function () {
        return this.monthes.map(function (month) { return month.date.month; });
    };
    Year.prototype.hasMonth = function (month) {
        return this.getExistMonthes().indexOf(month) !== -1;
    };
    return Year;
}());
var Month = /** @class */ (function () {
    function Month(date) {
        this.date = { year: date.year, month: date.month };
        this.days = [];
    }
    Month.prototype.getExistDays = function () {
        return this.days.map(function (day) { return day.date.date; });
    };
    Month.prototype.hasDay = function (date) {
        return this.getExistDays().indexOf(date) !== -1;
    };
    return Month;
}());
var GameDatas = /** @class */ (function () {
    function GameDatas() {
        this.years = [];
    }
    GameDatas.prototype.getExistYears = function () {
        return this.years.map(function (year) { return year.date.year; });
    };
    GameDatas.prototype.hasYear = function (year) {
        return this.getExistYears().includes(year);
    };
    return GameDatas;
}());
var Game = /** @class */ (function () {
    function Game(date, period, result) {
        this.date = date;
        this.period = period;
        this.result = result;
    }
    return Game;
}());
var Day = /** @class */ (function () {
    function Day(date) {
        this.date = date;
        this.games = [];
    }
    Day.prototype.getExistGames = function () {
        return this.games.map(function (game) { return game.period; });
    };
    Day.prototype.hasGame = function (gameid) {
        return this.getExistGames().includes(gameid);
    };
    return Day;
}());
/** Functions */
function sameDay(d1, d2) {
    return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
}
function getCarHistoryByPeriod(from, to, oriGameDatas) {
    var _this = this;
    if (oriGameDatas === void 0) { oriGameDatas = new GameDatas(); }
    return new Promise(function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
        var datep, dateend, promises;
        return __generator(this, function (_a) {
            try {
                datep = new Date();
                dateend = new Date();
                datep.setFullYear(from.year, from.month - 1, from.date);
                dateend.setFullYear(to.year, to.month - 1, to.date);
                dateend.setDate(dateend.getDate() + 1);
                promises = new Array();
                while (!sameDay(datep, dateend)) {
                    promises.push(getCarHistoryByDay(datep.getFullYear(), datep.getMonth() + 1, datep.getDate()).then(function (day) {
                        return putDayIntoGameDatas(oriGameDatas, day);
                    }));
                    datep.setDate(datep.getDate() + 1);
                }
                Promise.all(promises).then(function () { return resolve(oriGameDatas); });
            }
            catch (err) {
                console.error(err);
                reject(err);
            }
            return [2 /*return*/];
        });
    }); });
}
function putDayIntoGameDatas(gamedatas, day) {
    if (!gamedatas.hasYear(day.date.year)) {
        gamedatas.years.push(new Year(day.date));
    }
    var thisYear = gamedatas.years.find(function (year) { return year.date.year === day.date.year; });
    if (!thisYear.hasMonth(day.date.month)) {
        thisYear.monthes.push(new Month(day.date));
    }
    var thisMonth = thisYear.monthes.find(function (month) { return month.date.month === day.date.month; });
    if (!thisMonth.hasDay(day.date.date)) {
        thisMonth.days.push(day);
    }
}
function getCarHistoryByDay(year, month, date) {
    var _this = this;
    return new Promise(function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            try {
                https.get("https://988kjw.com/inc/get.asp?lt=vrpk10a&tt=lotteryList&dt=" + year + "-" + month + "-" + date, {
                    headers: {
                        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36",
                        Cookie: "ccsalt=e4d35ff5b245aecebd5fd355d6c9deb3; HJMK=3703790g984d1bc1c4d8a63f497dfc5455f9b461g1396me;"
                    }
                }, function (response) {
                    if (response.statusCode > 300 && response.statusCode < 400 && response.headers.location) {
                        console.error("** 從 988kjw.com 抓取數據時發生了意外錯誤，以下是 response headers **");
                        console.error(response.headers);
                        reject();
                    }
                    else {
                        var body = "";
                        response.on("data", function (chunk) {
                            body += chunk.toString();
                        });
                        response.on("end", function () {
                            return __awaiter(this, void 0, void 0, function () {
                                var _a;
                                return __generator(this, function (_b) {
                                    switch (_b.label) {
                                        case 0:
                                            _a = resolve;
                                            return [4 /*yield*/, parseDayObject(JSON.parse(body), {
                                                    year: year,
                                                    month: month,
                                                    date: date
                                                })];
                                        case 1:
                                            _a.apply(void 0, [_b.sent()]);
                                            exports.mainWindow.webContents.send("one-day-downloaded");
                                            return [2 /*return*/];
                                    }
                                });
                            });
                        });
                    }
                });
            }
            catch (err) {
                console.error(err);
            }
            return [2 /*return*/];
        });
    }); });
}
function parseDayObject(data, date) {
    return new Promise(function (resolve, reject) {
        try {
            var day = new Day(date);
            data.map(function (origame) {
                day.games.push(new Game(date, origame.issue, origame.openNum));
            });
            day.games.sort(function (gameA, gameB) { return gameA.period - gameB.period; });
            resolve(day);
        }
        catch (err) {
            reject(err);
        }
    });
}
/** Main */
var app = electron.app;
var BrowserWindow = electron.BrowserWindow;
app.allowRendererProcessReuse = true;
function createWindow() {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            exports.mainWindow = new BrowserWindow({
                width: 1200,
                height: 800,
                webPreferences: {
                    nodeIntegration: true
                }
            });
            exports.mainWindow.loadFile("build/index.html");
            exports.mainWindow.setMenu(null);
            return [2 /*return*/];
        });
    });
}
electron_1.ipcMain.on("give-me-game-datas", function (event, data) { return __awaiter(void 0, void 0, void 0, function () {
    var gamedata;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, getCarHistoryByPeriod(data.from, data.to, store)];
            case 1:
                gamedata = _a.sent();
                event.reply("give-you-game-datas", gamedata);
                return [2 /*return*/];
        }
    });
}); });
app.whenReady().then(createWindow);
app.on("window-all-closed", function () {
    if (process.platform !== "darwin") {
        app.quit();
    }
});
app.on("activate", function () {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});
/** 關於自動獲取歷史數據 */
var store = new GameDatas();
function downloadHistory(year) {
    return new Promise(function (resolve, reject) {
        https.get("https://www.1396r.com/xyft/downloadhistory?t=csv&start=" + year + "-01-01&end=" + year + "-12-31", {
            headers: {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36",
                Cookie: "ccsalt=e4d35ff5b245aecebd5fd355d6c9deb3; HJMK=3703790g984d1bc1c4d8a63f497dfc5455f9b461g1396me;"
            }
        }, function (response) {
            if (response.statusCode > 300 && response.statusCode < 400 && response.headers.location) {
                console.error("** 從 www.1396r.com 抓取數據時發生了意外錯誤，以下是 response headers **");
                console.error(response.headers);
                reject();
            }
            else {
                var body = "";
                response.on("data", function (chunk) {
                    body += chunk.toString();
                });
                response.on("end", function () {
                    console.log("獲取 " + year + " 年的比賽數據完成");
                    resolve(body);
                });
            }
        });
    });
}
function getHistory(year) {
    return __awaiter(this, void 0, void 0, function () {
        var dataString, lines;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, downloadHistory(year)];
                case 1:
                    dataString = _a.sent();
                    lines = dataString.split("\n");
                    console.log("開始解析 " + year + " 年的比賽數據，共 " + lines.length + " 筆");
                    lines.map(function (line) {
                        if (line.split(",")[1] === undefined)
                            return;
                        // 處理日期
                        var dateArray = line.split(",")[0].split("-");
                        var date = { year: +dateArray[0], month: +dateArray[1], date: +dateArray[2] };
                        // 處理期數
                        var period = +line.split(",")[1];
                        // 處理結果
                        var result = new Array();
                        for (var i = 2; i <= 11; i++)
                            result.push(+line.split(",")[i]);
                        // 創建場次物件
                        var game = new Game(date, period, result);
                        if (!store.hasYear(game.date.year)) {
                            store.years.push(new Year(game.date));
                        }
                        var thisYear = store.years.find(function (year) { return year.date.year === date.year; });
                        if (!thisYear.hasMonth(game.date.month)) {
                            thisYear.monthes.push(new Month(game.date));
                        }
                        var thisMonth = thisYear.monthes.find(function (month) { return month.date.month === date.month; });
                        if (!thisMonth.hasDay(game.date.date)) {
                            thisMonth.days.push(new Day(game.date));
                        }
                        var thisDay = thisMonth.days.find(function (day) { return day.date.date === date.date; });
                        thisDay.games.push(game);
                    });
                    console.log(" => " + year + " 年的比賽數據已經解析完成並可用於統計分析");
                    return [2 /*return*/];
            }
        });
    });
}
