import Day from "../classes/Day";
import { DayDate } from "../types";
import Game from "../classes/Game";
import * as https from "https";
import { mainWindow } from "../electron";

export default function getCarHistoryByDay(year: number, month: number, date: number) {
    return new Promise<Day>(async (resolve, reject) => {
        try {
            https.get(
                "https://988kjw.com/inc/get.asp?lt=vrpk10a&tt=lotteryList&dt=" + year + "-" + month + "-" + date,
                {
                    headers: {
                        "User-Agent":
                            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36",
                        Cookie: "ccsalt=e4d35ff5b245aecebd5fd355d6c9deb3; HJMK=3703790g984d1bc1c4d8a63f497dfc5455f9b461g1396me;",
                    },
                },
                function (response) {
                    if (response.statusCode > 300 && response.statusCode < 400 && response.headers.location) {
                        console.error("** 從 988kjw.com 抓取數據時發生了意外錯誤，以下是 response headers **");
                        console.error(response.headers);
                        reject();
                    } else {
                        var body = "";

                        response.on("data", function (chunk) {
                            body += chunk.toString();
                        });

                        response.on("end", async function () {
                            resolve(
                                await parseDayObject(JSON.parse(body), {
                                    year: year,
                                    month: month,
                                    date: date,
                                })
                            );
                            mainWindow.webContents.send("one-day-downloaded");
                        });
                    }
                }
            );
        } catch (err) {
            console.error(err);
        }
    });
}

function parseDayObject(data: Array<originGameData>, date: DayDate) {
    return new Promise<Day>((resolve, reject) => {
        try {
            var day = new Day(date);
            data.map((origame) => {
                day.games.push(new Game(date, origame.issue, origame.openNum));
            });
            day.games.sort((gameA, gameB) => gameA.period - gameB.period);
            resolve(day);
        } catch (err) {
            reject(err);
        }
    });
}

interface originGameData {
    openDateTime: string;
    issue: number;
    openNum: Array<number>;
    sumArr: Array<number>;
    dtArr: Array<number>;
    mimcryArr: any;
    formArr: any;
    sumStrArr: any;
}
