import * as electron from "electron";
import { ipcMain } from "electron";
import getCarHistoryByPeriod from "./methods/getCarHistoryByPeriod";

const app = electron.app;
const BrowserWindow = electron.BrowserWindow;

app.allowRendererProcessReuse = true;

export var mainWindow: electron.BrowserWindow;

async function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
        },
    });
    mainWindow.loadFile("build/index.html");
    mainWindow.setMenu(null);
}

ipcMain.on("give-me-game-datas", async (event, data: any) => {
    var gamedata = await getCarHistoryByPeriod(data.from, data.to);
    event.reply("give-you-game-datas", gamedata);
});

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        app.quit();
    }
});

app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});
